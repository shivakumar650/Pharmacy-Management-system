# Pharmacy System

Project scaffold for a pharmacy inventory and reporting system. Files are placeholders; implement logic as needed.
