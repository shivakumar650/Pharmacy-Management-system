const Medicine = require("../models/Medicine");

// ADD MEDICINE
exports.addMedicine = async (req, res) => {
  try {
    const { name, category } = req.body;

    if (!name) {
      return res.status(400).json({ message: "Medicine name is required" });
    }

    const medicine = new Medicine({ name, category });
    await medicine.save();

    res.status(201).json(medicine);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// GET ALL MEDICINES
exports.getMedicines = async (req, res) => {
  try {
    const medicines = await Medicine.find();
    res.json(medicines);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
