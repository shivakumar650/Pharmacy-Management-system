import { useEffect, useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { exportToCSV } from "./utils/exportCsv";

function Inventory() {
  const [data, setData] = useState([]);
  const [batches, setBatches] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [form, setForm] = useState({ medicineId: '', medicineName: '', batchNo: '', expiryDate: '', quantity: '', costPrice: '', sellingPrice: '' });
  const [medicines, setMedicines] = useState([]);
  const location = useLocation();

  const fetchInventory = async () => {
    try {
      const token = localStorage.getItem('token');
      const res = await fetch('/api/reports/inventory', { headers: { Authorization: `Bearer ${token}` } });
      if (!res.ok) throw new Error('Failed to fetch inventory');
      const json = await res.json();
      setData(json);
    } catch (e) {
      console.error('Fetch inventory error:', e);
      setData([]);
    }
  };

  const fetchBatches = async () => {
    try {
      const token = localStorage.getItem('token');
      const res = await fetch('/api/batches', { headers: { Authorization: `Bearer ${token}` } });
      if (!res.ok) throw new Error('Failed to fetch batches');
      const json = await res.json();
      setBatches(json);
    } catch (e) {
      console.error('Fetch batches error:', e);
      setBatches([]);
    }
  };

  const fetchMedicines = async () => {
    try {
      const token = localStorage.getItem('token');
      const res = await fetch('/api/medicines', { headers: { Authorization: `Bearer ${token}` } });
      if (!res.ok) throw new Error('Failed to fetch medicines');
      const json = await res.json();
      setMedicines(json);
    } catch (e) {
      console.error('Fetch medicines error:', e);
      setMedicines([]);
    }
  };

  useEffect(() => {
    setLoading(true);
    setError(null);
    Promise.all([fetchInventory(), fetchBatches(), fetchMedicines()])
      .then(() => setLoading(false))
      .catch(err => {
        console.error('Error loading inventory:', err);
        setError('Failed to load inventory');
        setLoading(false);
      });
  }, [location]);

  const handleInput = (e) => setForm(prev => ({ ...prev, [e.target.name]: e.target.value }));

  const handleAddBatch = async (e) => {
    e.preventDefault();
    try {
      // validate expiry is in the future
      if (new Date(form.expiryDate) <= new Date()) {
        alert('Expiry date must be in the future');
        return;
      }

      let medicineIdToUse = form.medicineId;
      // if no existing medicine selected but a name provided, create the medicine first
      if (!medicineIdToUse && form.medicineName && form.medicineName.trim() !== '') {
        const createMedRes = await fetch('/api/medicines', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${localStorage.getItem('token')}` },
          body: JSON.stringify({ name: form.medicineName.trim() })
        });
        if (!createMedRes.ok) {
          const err = await createMedRes.json();
          alert(err.message || 'Failed to create medicine');
          return;
        }
        const createdMed = await createMedRes.json();
        medicineIdToUse = createdMed._id;
        // refresh medicines list
        fetchMedicines();
      }
      const res = await fetch('/api/batches', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${localStorage.getItem('token')}` },
        body: JSON.stringify({
          medicineId: medicineIdToUse,
          batchNo: form.batchNo,
          expiryDate: form.expiryDate,
          quantity: Number(form.quantity),
          costPrice: Number(form.costPrice) || 0,
          sellingPrice: Number(form.sellingPrice) || 0
        })
      });

      if (!res.ok) {
        const err = await res.json();
        alert(err.message || 'Failed to add batch');
        return;
      }

      const added = await res.json();
      setBatches(prev => [added, ...prev]);
      // refresh summary
      fetchInventory();
      setForm({ medicineId: '', medicineName: '', batchNo: '', expiryDate: '', quantity: '', costPrice: '', sellingPrice: '' });
    } catch (err) {
      console.error(err);
      alert('Error adding batch');
    }
  };

  const handleDeleteBatch = async (id) => {
    if (!confirm('Delete this batch?')) return;
    try {
      const res = await fetch(`/api/batches/${id}`, { method: 'DELETE', headers: { Authorization: `Bearer ${localStorage.getItem('token')}` } });
      if (!res.ok) {
        const err = await res.json();
        alert(err.message || 'Delete failed');
        return;
      }
      setBatches(prev => prev.filter(b => b._id !== id));
      fetchInventory();
    } catch (e) { console.error(e); alert('Error deleting'); }
  };

  const handleSell = async (batch) => {
    const qty = prompt(`Enter quantity to sell (Available: ${batch.quantity})`);
    if (!qty || qty <= 0) return;
    if (Number(qty) > batch.quantity) {
      alert('Insufficient stock!');
      return;
    }
    try {
      const res = await fetch('/api/sales', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${localStorage.getItem('token')}` },
        body: JSON.stringify({ batchId: batch._id, quantity: Number(qty) })
      });
      if (!res.ok) {
        const err = await res.json();
        alert(err.message || 'Sale failed');
        return;
      }
      alert('Sale recorded successfully!');
      fetchBatches();
      fetchInventory();
    } catch (e) { console.error(e); alert('Error recording sale'); }
  };

  if (loading) return (
    <div className="page-container">
      <div className="loading-container">
        <p>Loading inventory...</p>
      </div>
    </div>
  );
  
  if (error) return (
    <div className="page-container">
      <div className="error-message">
        <strong>Error:</strong> {error}. Please ensure the backend server is running.
      </div>
    </div>
  );

  return (
    <div className="page-container">
      <h2 style={{ marginBottom: 32, textAlign: 'center', fontSize: '28px', fontWeight: 700 }}>Inventory Management</h2>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 20, alignItems: 'center' }}>
        <div style={{ width: '100%', display: 'flex', justifyContent: 'center', alignItems: 'center', gap: 16, flexWrap: 'wrap' }}>
          <Link to="/inventory/add"><button type="button" className="add-stock-btn">Add Stock</button></Link>
        </div>

        <div className="table-container" style={{ width: '100%', maxWidth: 1100, position: 'relative' }}>
          <button onClick={() => exportToCSV('inventory-report.csv', data)} className="export-btn" style={{ position: 'absolute', top: '-50px', right: '0', display: 'flex', alignItems: 'center', gap: '8px' }}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
              <polyline points="7 10 12 15 17 10"></polyline>
              <line x1="12" y1="15" x2="12" y2="3"></line>
            </svg>
            Export CSV
          </button>
          <table>
            <thead>
              <tr>
                <th>Medicine</th>
                <th>Batch</th>
                <th>Expiry Date</th>
                <th>Qty</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {batches.map(b => (
                <tr key={b._id} className={new Date(b.expiryDate) <= new Date() ? 'critical-row' : ''}>
                  <td>{b.medicine?.name || '—'}</td>
                  <td>{b.batchNo}</td>
                  <td>{new Date(b.expiryDate).toLocaleDateString()}</td>
                  <td>{b.quantity}</td>
                  <td>
                    <button onClick={() => handleSell(b)} style={{ marginRight: 8, background: '#10b981', color: 'white' }} className="export-btn">💰 Sell</button>
                    <button onClick={() => handleDeleteBatch(b._id)} style={{ marginRight: 8 }} className="export-btn">🗑️ Delete</button>
                    {new Date(b.expiryDate) <= new Date() && <span className="status-badge status-critical">Expired</span>}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <h3 style={{ marginTop: 32, marginBottom: 16, textAlign: 'center' }}>Inventory Summary</h3>
      {data.length === 0 ? (
        <p style={{ textAlign: 'center' }}>No inventory data available</p>
      ) : (
        <div className="table-container" style={{ maxWidth: 1100, margin: '0 auto' }}>
          <table>
            <thead>
              <tr>
                <th>Medicine Name</th>
                <th>Total Quantity</th>
                <th>Total Stock Value ($)</th>
              </tr>
            </thead>
            <tbody>
              {data.map((item, i) => (
                <tr key={i}>
                  <td>{item.medicineName}</td>
                  <td>{item.totalQuantity}</td>
                  <td>${item.totalStockValue?.toFixed(2) || '0.00'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

export default Inventory;
