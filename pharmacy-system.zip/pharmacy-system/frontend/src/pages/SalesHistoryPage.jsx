import { useState, useEffect } from 'react';

function SalesHistoryPage() {
  const [sales, setSales] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchSales();
  }, []);

  const fetchSales = async () => {
    try {
      const token = localStorage.getItem('token');
      console.log('Fetching sales with token:', token ? 'Token exists' : 'No token');
      
      const res = await fetch('/api/sales', {
        headers: { 
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        cache: 'no-cache'
      });
      
      console.log('Response status:', res.status);
      
      if (res.ok) {
        const data = await res.json();
        console.log('Sales data received:', data);
        setSales(data);
      } else {
        const errorText = await res.text();
        console.error('Failed to fetch sales:', res.status, errorText);
        setError(`Failed to load sales: ${res.status}`);
      }
    } catch (err) {
      console.error('Error fetching sales:', err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  if (loading) return <div className="loading-container"><p>Loading...</p></div>;
  if (error) return <div className="loading-container"><p style={{color: 'red'}}>Error: {error}</p></div>;

  const totalSales = sales.reduce((sum, sale) => sum + sale.totalAmount, 0);

  return (
    <div>
      <h2 style={{ marginBottom: 32, textAlign: 'center', fontSize: '28px', fontWeight: 700 }}>Sales History</h2>

      <div style={{ marginBottom: 24, textAlign: 'center' }}>
        <div style={{ display: 'inline-block', padding: '16px 32px', background: 'rgba(16,185,129,0.1)', borderRadius: '12px' }}>
          <p style={{ margin: 0, fontSize: '14px', color: '#64748b' }}>Total Sales</p>
          <p style={{ margin: 0, fontSize: '28px', fontWeight: 700, color: '#10b981' }}>${totalSales.toFixed(2)}</p>
        </div>
      </div>

      <div className="table-container" style={{ maxWidth: 1100, margin: '0 auto' }}>
        {sales.length === 0 ? (
          <p style={{ textAlign: 'center', padding: '40px' }}>No sales recorded yet</p>
        ) : (
          <table>
            <thead>
              <tr>
                <th>Invoice #</th>
                <th>Customer</th>
                <th>Medicine</th>
                <th>Batch</th>
                <th>Quantity</th>
                <th>Price</th>
                <th>Total</th>
                <th>Date</th>
              </tr>
            </thead>
            <tbody>
              {sales.map((sale) => (
                <tr key={sale._id}>
                  <td>{sale.invoiceNumber || 'N/A'}</td>
                  <td>{sale.customer?.name || 'Walk-in'}</td>
                  <td>{sale.medicine?.name || 'N/A'}</td>
                  <td>{sale.batch?.batchNo || 'N/A'}</td>
                  <td>{sale.quantity}</td>
                  <td>${(sale.sellingPrice || 0).toFixed(2)}</td>
                  <td>${(sale.totalAmount || 0).toFixed(2)}</td>
                  <td>{new Date(sale.soldAt).toLocaleString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

export default SalesHistoryPage;
