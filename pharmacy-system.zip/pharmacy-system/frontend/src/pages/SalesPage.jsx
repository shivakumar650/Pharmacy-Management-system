import { Link } from 'react-router-dom';

function SalesPage() {
  return (
    <div style={{ maxWidth: 900, margin: '0 auto', padding: '20px' }}>
      <h2 style={{ marginBottom: 32, textAlign: 'center', fontSize: '28px', fontWeight: 700 }}>💰 Sales Management</h2>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: 24 }}>
        <Link to="/record-sale" style={{ textDecoration: 'none' }}>
          <div style={{ 
            background: 'rgba(255,255,255,0.95)', 
            padding: '40px', 
            borderRadius: '16px', 
            boxShadow: '0 4px 12px rgba(0,0,0,0.1)',
            textAlign: 'center',
            cursor: 'pointer',
            transition: 'transform 0.3s ease',
            border: '2px solid transparent'
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.transform = 'translateY(-4px)';
            e.currentTarget.style.borderColor = '#2563eb';
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.transform = 'translateY(0)';
            e.currentTarget.style.borderColor = 'transparent';
          }}>
            <div style={{ fontSize: '48px', marginBottom: 16 }}>🛒</div>
            <h3 style={{ margin: '0 0 12px 0', color: '#2563eb', fontSize: '22px' }}>Record Sale</h3>
            <p style={{ margin: 0, color: '#64748b' }}>Record new medicine sales and update inventory</p>
          </div>
        </Link>

        <Link to="/sales-history" style={{ textDecoration: 'none' }}>
          <div style={{ 
            background: 'rgba(255,255,255,0.95)', 
            padding: '40px', 
            borderRadius: '16px', 
            boxShadow: '0 4px 12px rgba(0,0,0,0.1)',
            textAlign: 'center',
            cursor: 'pointer',
            transition: 'transform 0.3s ease',
            border: '2px solid transparent'
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.transform = 'translateY(-4px)';
            e.currentTarget.style.borderColor = '#10b981';
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.transform = 'translateY(0)';
            e.currentTarget.style.borderColor = 'transparent';
          }}>
            <div style={{ fontSize: '48px', marginBottom: 16 }}>📊</div>
            <h3 style={{ margin: '0 0 12px 0', color: '#10b981', fontSize: '22px' }}>Sales History</h3>
            <p style={{ margin: 0, color: '#64748b' }}>View all sales records and export reports</p>
          </div>
        </Link>
      </div>
    </div>
  );
}

export default SalesPage;
