import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Bar, Pie } from "react-chartjs-2";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  ArcElement,
  Tooltip,
  Legend
} from "chart.js";

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  ArcElement,
  Tooltip,
  Legend
);

function Dashboard() {
  const [inventory, setInventory] = useState([
    { medicineName: 'Paracetamol 500mg', totalQuantity: 150, totalStockValue: 75.00 },
    { medicineName: 'Amoxicillin 250mg', totalQuantity: 200, totalStockValue: 120.00 },
    { medicineName: 'Ibuprofen 400mg', totalQuantity: 100, totalStockValue: 80.00 },
    { medicineName: 'Vitamin C Tablets', totalQuantity: 300, totalStockValue: 45.00 },
    { medicineName: 'Aspirin 75mg', totalQuantity: 180, totalStockValue: 36.00 },
    { medicineName: 'Omeprazole 20mg', totalQuantity: 90, totalStockValue: 135.00 }
  ]);
  const [expiry, setExpiry] = useState([
    { medicineName: 'Paracetamol 500mg', quantity: 25, daysLeft: 5 },
    { medicineName: 'Vitamin C Tablets', quantity: 50, daysLeft: 15 },
    { medicineName: 'Aspirin 75mg', quantity: 30, daysLeft: 25 }
  ]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    // Try to fetch real data, but don't break if it fails
    const fetchData = async () => {
      try {
        const token = localStorage.getItem('token');
        if (!token) return;
        
        const [invRes, expRes] = await Promise.allSettled([
          fetch('/api/reports/inventory', {
            headers: { 'Authorization': `Bearer ${token}` }
          }),
          fetch('/api/reports/expiry?days=30', {
            headers: { 'Authorization': `Bearer ${token}` }
          })
        ]);
        
        if (invRes.status === 'fulfilled' && invRes.value.ok) {
          const invData = await invRes.value.json();
          if (invData && invData.length > 0) {
            setInventory(invData);
          }
        }
        
        if (expRes.status === 'fulfilled' && expRes.value.ok) {
          const expData = await expRes.value.json();
          if (expData && expData.length > 0) {
            setExpiry(expData);
          }
        }
      } catch (err) {
        console.log('Using default sample data');
        setError('Using sample data - API connection failed');
      }
    };
    
    fetchData();
  }, []);

  if (loading) {
    return (
      <div className="dashboard-wrapper">
        <div className="loading-container">
          <div className="spinner"></div>
          <p>Loading your dashboard...</p>
        </div>
      </div>
    );
  }

  // Calculate stats
  const totalMedicines = inventory.length;
  const totalQuantity = inventory.reduce((sum, item) => sum + item.totalQuantity, 0);
  const totalStockValue = inventory.reduce((sum, item) => sum + item.totalStockValue, 0);
  const criticalExpiry = expiry.filter(item => item.daysLeft <= 7).length;
  const warningExpiry = expiry.filter(item => item.daysLeft > 7 && item.daysLeft <= 30).length;

  // Chart Data
  const topMedicines = inventory.slice(0, 6);
  const stockChartData = {
    labels: topMedicines.map(m => m.medicineName),
    datasets: [
      {
        label: "Stock Value ($)",
        data: topMedicines.map(m => m.totalStockValue),
        backgroundColor: [
          "#3b82f6",
          "#10b981",
          "#f59e0b",
          "#ef4444",
          "#8b5cf6",
          "#06b6d4"
        ],
        borderColor: "rgba(255, 255, 255, 0.2)",
        borderWidth: 2
      }
    ]
  };

  const expiryDistributionData = {
    labels: ["Critical (0-7 days)", "Warning (8-30 days)", "Healthy"],
    datasets: [
      {
        label: "Medicines",
        data: [
          criticalExpiry,
          warningExpiry,
          inventory.length - criticalExpiry - warningExpiry
        ],
        backgroundColor: ["#ef4444", "#f59e0b", "#10b981"],
        borderColor: "rgba(255, 255, 255, 0.2)",
        borderWidth: 2
      }
    ]
  };

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: true,
    plugins: {
      legend: {
        labels: {
          color: "var(--text-color)",
          font: { size: 12, weight: "600" }
        }
      }
    },
    scales: {
      y: {
        ticks: { color: "var(--text-light)" },
        grid: { color: "rgba(0, 0, 0, 0.05)" }
      },
      x: {
        ticks: { color: "var(--text-light)" },
        grid: { color: "rgba(0, 0, 0, 0.05)" }
      }
    }
  };

  const pieOptions = {
    responsive: true,
    maintainAspectRatio: true,
    plugins: {
      legend: {
        labels: {
          color: "var(--text-color)",
          font: { size: 12, weight: "600" }
        }
      }
    }
  };

  return (
    <div className="dashboard-wrapper">
      {/* Header Section */}
      <div className="dashboard-header">
        <div className="header-content">
          <h1 className="header-title">
            <span className="header-icon">🏥</span>
            PharmaCare Dashboard
          </h1>
          <p className="header-subtitle">
            Monitor inventory, track expiry dates, and manage your pharmacy with real-time analytics
          </p>
        </div>
        <div className="header-illustration">
          <div className="illustration-box">📊</div>
        </div>
      </div>

      {error && (
        <div className="error-banner">
          <span className="error-icon">⚠️</span>
          <div className="error-content">
            <strong>Error Loading Dashboard</strong>
            <p>{error}</p>
          </div>
        </div>
      )}

      {/* Main Stats Grid */}
      <div className="stats-grid">
        <div className="stat-card premium">
          <div className="stat-card-header">
            <div className="stat-icon-large">📊</div>
            <div className="stat-label">Total Medicines</div>
          </div>
          <div className="stat-value">{totalMedicines}</div>
          <div className="stat-subtext">Different medication types</div>
          <div className="stat-badge">Active</div>
        </div>

        <div className="stat-card premium">
          <div className="stat-card-header">
            <div className="stat-icon-large">📦</div>
            <div className="stat-label">Total Quantity</div>
          </div>
          <div className="stat-value">{totalQuantity.toLocaleString()}</div>
          <div className="stat-subtext">Units in stock</div>
          <div className="stat-badge">Inventory</div>
        </div>

        <div className="stat-card premium success">
          <div className="stat-card-header">
            <div className="stat-icon-large">💰</div>
            <div className="stat-label">Stock Value</div>
          </div>
          <div className="stat-value">${totalStockValue.toFixed(2)}</div>
          <div className="stat-subtext">Total inventory value</div>
          <div className="stat-badge">Assets</div>
        </div>

        <div className={`stat-card premium ${criticalExpiry > 0 ? 'danger' : 'warning'}`}>
          <div className="stat-card-header">
            <div className="stat-icon-large">⚠️</div>
            <div className="stat-label">Critical Expiry</div>
          </div>
          <div className="stat-value">{criticalExpiry}</div>
          <div className="stat-subtext">Expiring in 0-7 days</div>
          <div className="stat-badge">Alert</div>
        </div>
      </div>

      {/* Charts Section */}
      <div className="charts-section">
        <div className="section-title">
          <h2>📈 Analytics & Insights</h2>
          <p>Real-time visualization of your pharmacy data</p>
        </div>

        <div className="charts-grid">
          <div className="chart-card">
            <div className="chart-header">
              <h3>Top Medicine Stock Values</h3>
              <span className="chart-info">Top 6 by value</span>
            </div>
            <div className="chart-container">
              <Bar data={stockChartData} options={chartOptions} />
            </div>
          </div>

          <div className="chart-card">
            <div className="chart-header">
              <h3>Expiry Status Distribution</h3>
              <span className="chart-info">All medicines</span>
            </div>
            <div className="chart-container pie-container">
              <Pie data={expiryDistributionData} options={pieOptions} />
            </div>
          </div>
        </div>
      </div>

      {/* Features Grid */}
      <div className="features-section">
        <div className="section-title">
          <h2>⚡ Quick Actions</h2>
          <p>Access key features directly from the dashboard</p>
        </div>

        <div className="features-grid">
          <Link to="/inventory" className="feature-card">
            <div className="feature-icon">📦</div>
            <h3>Manage Inventory</h3>
            <p>Add, edit, and view medicines in stock</p>
            <div className="feature-arrow">→</div>
          </Link>

          <Link to="/expiry-alerts" className="feature-card">
            <div className="feature-icon">⏰</div>
            <h3>Expiry Alerts</h3>
            <p>Monitor expiring medicines and take action</p>
            <div className="feature-arrow">→</div>
          </Link>

          <Link to="/about" className="feature-card">
            <div className="feature-icon">ℹ️</div>
            <h3>About PharmaCare</h3>
            <p>Learn more about our system and benefits</p>
            <div className="feature-arrow">→</div>
          </Link>

          <Link to="/tech-stack" className="feature-card">
            <div className="feature-icon">🛠️</div>
            <h3>Technology Stack</h3>
            <p>Explore the technologies powering PharmaCare</p>
            <div className="feature-arrow">→</div>
          </Link>
        </div>
      </div>

      {/* Expiry Items List */}
      {expiry.length > 0 && (
        <div className="expiry-section">
          <div className="section-title">
            <h2>⚠️ Recent Expiry Items</h2>
            <p>Medicines expiring within 30 days - {expiry.length} items</p>
          </div>

          <div className="expiry-table-wrapper">
            <table className="expiry-table">
              <thead>
                <tr>
                  <th>Medicine Name</th>
                  <th>Quantity</th>
                  <th>Days Left</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {expiry.slice(0, 5).map((item, idx) => (
                  <tr key={idx} className={`expiry-row ${item.daysLeft <= 7 ? 'critical' : 'warning'}`}>
                    <td className="med-name">{item.medicineName}</td>
                    <td>{item.quantity}</td>
                    <td className="days-left">{item.daysLeft} days</td>
                    <td>
                      <span className={`status-badge ${item.daysLeft <= 7 ? 'critical' : 'warning'}`}>
                        {item.daysLeft <= 7 ? 'Critical' : 'Warning'}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {expiry.length > 5 && (
            <Link to="/expiry-alerts" className="view-all-link">
              View All {expiry.length} Expiring Items →
            </Link>
          )}
        </div>
      )}

      {/* Info Cards */}
      <div className="info-section">
        <div className="info-card info-primary">
          <div className="info-icon">✨</div>
          <h4>Real-Time Updates</h4>
          <p>All data is updated in real-time to reflect current inventory status</p>
        </div>

        <div className="info-card info-success">
          <div className="info-icon">🔒</div>
          <h4>Secure & Reliable</h4>
          <p>Enterprise-grade security ensures your pharmacy data stays protected</p>
        </div>

        <div className="info-card info-warning">
          <div className="info-icon">📱</div>
          <h4>Mobile Friendly</h4>
          <p>Access your pharmacy management system from any device, anywhere</p>
        </div>

        <div className="info-card info-info">
          <div className="info-icon">⚙️</div>
          <h4>Easy to Use</h4>
          <p>Intuitive interface designed for quick and efficient management</p>
        </div>
      </div>
    </div>
  );
}

export default Dashboard;