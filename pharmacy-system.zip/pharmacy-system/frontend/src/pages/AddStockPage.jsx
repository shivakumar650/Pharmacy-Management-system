import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

export default function AddStockPage() {
  const [form, setForm] = useState({ medicineId: '', medicineName: '', batchNo: '', expiryDate: '', quantity: '', costPrice: '', sellingPrice: '' });
  const [medicines, setMedicines] = useState([]);
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState({});
  const [showModal, setShowModal] = useState(true);
  const navigate = useNavigate();

  useEffect(() => { fetchMedicines(); }, []);

  const fetchMedicines = async () => {
    try {
      const res = await fetch('/api/medicines', { headers: { Authorization: `Bearer ${localStorage.getItem('token')}` } });
      if (!res.ok) throw new Error('Failed to fetch');
      const json = await res.json();
      setMedicines(json);
    } catch (e) { console.error(e); setMedicines([]);}
  };

  const handleInput = (e) => {
    const { name, value } = e.target;
    setForm(prev => ({ ...prev, [name]: value }));
    if (errors[name]) setErrors(prev => ({ ...prev, [name]: '' }));
  };

  const validate = () => {
    const newErrors = {};
    if (!form.medicineId && !form.medicineName) newErrors.medicine = 'Select or enter a medicine';
    if (!form.batchNo) newErrors.batchNo = 'Batch No is required';
    if (!form.expiryDate) newErrors.expiryDate = 'Expiry date is required';
    if (form.expiryDate && new Date(form.expiryDate) <= new Date()) newErrors.expiryDate = 'Expiry date must be in future';
    if (!form.quantity) newErrors.quantity = 'Quantity is required';
    if (form.quantity && isNaN(form.quantity)) newErrors.quantity = 'Quantity must be a number';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validate()) return;
    setLoading(true);
    try {
      let medicineIdToUse = form.medicineId;
      if (!medicineIdToUse && form.medicineName && form.medicineName.trim() !== '') {
        const createMedRes = await fetch('/api/medicines', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${localStorage.getItem('token')}` }, body: JSON.stringify({ name: form.medicineName.trim() }) });
        if (!createMedRes.ok) { const err = await createMedRes.json(); setErrors({ submit: err.message || 'Failed to create medicine' }); setLoading(false); return; }
        const createdMed = await createMedRes.json();
        medicineIdToUse = createdMed._id;
      }

      const res = await fetch('/api/batches', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${localStorage.getItem('token')}` }, body: JSON.stringify({ medicineId: medicineIdToUse, batchNo: form.batchNo, expiryDate: form.expiryDate, quantity: Number(form.quantity), costPrice: Number(form.costPrice) || 0, sellingPrice: Number(form.sellingPrice) || 0 }) });
      if (!res.ok) { const err = await res.json(); setErrors({ submit: err.message || 'Failed to add batch' }); setLoading(false); return; }
      setShowModal(false);
      setTimeout(() => navigate('/inventory'), 300);
    } catch (e) { console.error(e); setErrors({ submit: 'Error adding batch' }); setLoading(false); }
  };

  const handleClose = () => {
    setShowModal(false);
    setTimeout(() => navigate('/inventory'), 300);
  };

  return (
    <div className="page-container">
      <div className="modal-overlay" onClick={handleClose}></div>
      <div className="modal-dialog">
        <div className="modal-header">
          <h2>Add Stock</h2>
          <button type="button" className="modal-close" onClick={handleClose}>✕</button>
        </div>
        <form onSubmit={handleSubmit} className="add-batch-form modal-form">
          {errors.submit && <div className="form-error-banner">{errors.submit}</div>}

          <div className="form-group">
            <label>Medicine</label>
            <select name="medicineId" value={form.medicineId} onChange={handleInput} className={errors.medicine ? 'input-error' : ''}>
              <option value="">Select existing medicine (optional)</option>
              {medicines.map(m => <option key={m._id} value={m._id}>{m.name}</option>)}
            </select>
            {errors.medicine && <span className="field-error">{errors.medicine}</span>}
          </div>

          <div className="form-group">
            <label style={{ fontSize: 13, color: 'var(--text-muted)' }}>Or enter new medicine name</label>
            <input name="medicineName" value={form.medicineName} onChange={handleInput} placeholder="e.g. NewMedicine 10mg" className={errors.medicine ? 'input-error' : ''} />
          </div>

          <div className="form-group">
            <label>Batch No</label>
            <input name="batchNo" value={form.batchNo} onChange={handleInput} className={errors.batchNo ? 'input-error' : ''} />
            {errors.batchNo && <span className="field-error">{errors.batchNo}</span>}
          </div>

          <div className="form-group">
            <label>Expiry Date</label>
            <input name="expiryDate" type="date" value={form.expiryDate} onChange={handleInput} className={errors.expiryDate ? 'input-error' : ''} />
            {errors.expiryDate && <span className="field-error">{errors.expiryDate}</span>}
          </div>

          <div className="form-group">
            <label>Quantity</label>
            <input name="quantity" type="number" value={form.quantity} onChange={handleInput} className={errors.quantity ? 'input-error' : ''} />
            {errors.quantity && <span className="field-error">{errors.quantity}</span>}
          </div>

          <div className="form-group">
            <label>Cost Price</label>
            <input name="costPrice" type="number" step="0.01" value={form.costPrice} onChange={handleInput} />
          </div>

          <div className="form-group">
            <label>Selling Price</label>
            <input name="sellingPrice" type="number" step="0.01" value={form.sellingPrice} onChange={handleInput} />
          </div>

          <div style={{ display: 'flex', gap: 12, marginTop: 20 }}>
            <button className="primary" type="submit" disabled={loading}>{loading ? 'Adding...' : '➕ Add Stock'}</button>
            <button type="button" onClick={handleClose} disabled={loading}>Cancel</button>
          </div>
        </form>
      </div>
    </div>
  );
}
