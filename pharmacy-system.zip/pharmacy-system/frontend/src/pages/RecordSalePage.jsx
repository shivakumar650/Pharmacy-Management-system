import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

function RecordSalePage() {
  const [batches, setBatches] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [form, setForm] = useState({ batchId: '', quantity: '', customerId: '' });
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    fetchBatches();
    fetchCustomers();
  }, []);

  const fetchBatches = async () => {
    try {
      const token = localStorage.getItem('token');
      const res = await fetch('/api/batches', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const data = await res.json();
      setBatches(data.filter(b => b.quantity > 0));
    } catch (err) {
      console.error('Error fetching batches:', err);
    }
  };

  const fetchCustomers = async () => {
    try {
      const token = localStorage.getItem('token');
      const res = await fetch('/api/customers', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (res.ok) {
        const data = await res.json();
        setCustomers(data);
      }
    } catch (err) {
      console.error('Error fetching customers:', err);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const token = localStorage.getItem('token');
      const res = await fetch('/api/sales', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          batchId: form.batchId,
          quantity: Number(form.quantity),
          customerId: form.customerId || null
        })
      });

      if (!res.ok) {
        const err = await res.json();
        alert(err.message || 'Failed to record sale');
        setLoading(false);
        return;
      }

      const result = await res.json();
      console.log('Sale recorded:', result);
      alert('Sale recorded successfully!');
      setForm({ batchId: '', quantity: '' });
      navigate('/sales-history');
    } catch (err) {
      console.error('Error recording sale:', err);
      alert('Error recording sale');
    } finally {
      setLoading(false);
    }
  };

  const selectedBatch = batches.find(b => b._id === form.batchId);

  return (
    <div style={{ maxWidth: 600, margin: '0 auto' }}>
      <h2 style={{ marginBottom: 32, textAlign: 'center', fontSize: '28px', fontWeight: 700 }}>🛒 Record Sale</h2>

      <form onSubmit={handleSubmit} style={{ background: 'rgba(255,255,255,0.95)', padding: '32px', borderRadius: '16px', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}>
        <div className="form-group" style={{ marginBottom: 20 }}>
          <label>Select Customer (Optional)</label>
          <select
            value={form.customerId}
            onChange={(e) => setForm({ ...form, customerId: e.target.value })}
            style={{ width: '100%', padding: '12px', borderRadius: '8px', border: '2px solid #e2e8f0', fontSize: '16px' }}
          >
            <option value="">-- Walk-in Customer --</option>
            {customers.map(customer => (
              <option key={customer._id} value={customer._id}>
                {customer.name} - {customer.phone}
              </option>
            ))}
          </select>
        </div>

        <div className="form-group" style={{ marginBottom: 20 }}>
          <label>Select Medicine Batch</label>
          <select
            value={form.batchId}
            onChange={(e) => setForm({ ...form, batchId: e.target.value })}
            required
            style={{ width: '100%', padding: '12px', borderRadius: '8px', border: '2px solid #e2e8f0', fontSize: '16px' }}
          >
            <option value="">-- Select Batch --</option>
            {batches.map(batch => (
              <option key={batch._id} value={batch._id}>
                {batch.medicine?.name} - {batch.batchNo} (Stock: {batch.quantity})
              </option>
            ))}
          </select>
        </div>

        {selectedBatch && (
          <div style={{ padding: '16px', background: '#f0f9ff', borderRadius: '8px', marginBottom: 20 }}>
            <p style={{ margin: '4px 0' }}><strong>Available:</strong> {selectedBatch.quantity} units</p>
            <p style={{ margin: '4px 0' }}><strong>Price:</strong> ${selectedBatch.sellingPrice || 0} per unit</p>
          </div>
        )}

        <div className="form-group" style={{ marginBottom: 20 }}>
          <label>Quantity</label>
          <input
            type="number"
            value={form.quantity}
            onChange={(e) => setForm({ ...form, quantity: e.target.value })}
            min="1"
            max={selectedBatch?.quantity || 1}
            required
            style={{ width: '100%', padding: '12px', borderRadius: '8px', border: '2px solid #e2e8f0', fontSize: '16px' }}
          />
        </div>

        {selectedBatch && form.quantity && (
          <div style={{ padding: '16px', background: '#f0fdf4', borderRadius: '8px', marginBottom: 20 }}>
            <p style={{ margin: 0, fontSize: '18px', fontWeight: 600 }}>
              Total: ${((selectedBatch.sellingPrice || 0) * Number(form.quantity)).toFixed(2)}
            </p>
          </div>
        )}

        <button type="submit" disabled={loading} className="primary" style={{ width: '100%', padding: '14px' }}>
          {loading ? 'Recording...' : 'Record Sale'}
        </button>
      </form>
    </div>
  );
}

export default RecordSalePage;
