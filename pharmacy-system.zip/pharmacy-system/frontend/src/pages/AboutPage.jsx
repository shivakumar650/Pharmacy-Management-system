import { Link } from "react-router-dom";

function AboutPage() {
  return (
    <div className="page-container">
      <div className="page-header">
        <h1>ℹ️ About PharmaCare</h1>
        <p>Learn more about our comprehensive pharmacy management solution</p>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '32px', alignItems: 'start' }}>
        <div>
          <h3 style={{ color: 'var(--primary-color)', marginBottom: '16px', fontSize: '20px' }}>🎯 Our Mission</h3>
          <p style={{ lineHeight: '1.7', color: 'var(--text-light)' }}>
            PharmaCare is designed to revolutionize pharmacy management by providing healthcare professionals
            with powerful, intuitive tools to manage inventory, track expiry dates, and ensure patient safety.
            Our system combines cutting-edge technology with user-friendly design to streamline pharmacy operations.
          </p>
        </div>
        <div>
          <h3 style={{ color: 'var(--success-color)', marginBottom: '16px', fontSize: '20px' }}>🚀 Key Features</h3>
          <ul style={{ lineHeight: '1.8', color: 'var(--text-light)', paddingLeft: '20px' }}>
            <li>Real-time inventory tracking and management</li>
            <li>Automated expiry date monitoring and alerts</li>
            <li>Comprehensive reporting and analytics</li>
            <li>Secure user authentication and authorization</li>
            <li>Responsive design for all devices</li>
            <li>CSV export functionality for data analysis</li>
          </ul>
        </div>
        <div>
          <h3 style={{ color: 'var(--warning-color)', marginBottom: '16px', fontSize: '20px' }}>💡 Why Choose PharmaCare?</h3>
          <p style={{ lineHeight: '1.7', color: 'var(--text-light)' }}>
            Built with modern web technologies including React, Node.js, and MongoDB, PharmaCare offers
            a robust, scalable solution that grows with your pharmacy. Our intuitive interface reduces
            training time while our powerful features ensure compliance and efficiency in your daily operations.
          </p>
        </div>
      </div>

      <div className="about-stats">
        <div className="about-stat-card">
          <div className="stat-icon">🏥</div>
          <div className="stat-content">
            <h3>Healthcare Focused</h3>
            <p>Designed specifically for pharmacy management needs</p>
          </div>
        </div>
        <div className="about-stat-card">
          <div className="stat-icon">🔒</div>
          <div className="stat-content">
            <h3>Secure & Reliable</h3>
            <p>Enterprise-grade security with data protection</p>
          </div>
        </div>
        <div className="about-stat-card">
          <div className="stat-icon">⚡</div>
          <div className="stat-content">
            <h3>Fast & Efficient</h3>
            <p>Optimized performance for quick operations</p>
          </div>
        </div>
        <div className="about-stat-card">
          <div className="stat-icon">📱</div>
          <div className="stat-content">
            <h3>Mobile Ready</h3>
            <p>Works seamlessly across all devices</p>
          </div>
        </div>
      </div>

      <div className="about-contact">
        <h3 style={{ color: 'var(--primary-color)', marginBottom: '16px' }}>📞 Get in Touch</h3>
        <p style={{ lineHeight: '1.7', color: 'var(--text-light)', marginBottom: '20px' }}>
          Have questions about PharmaCare? We'd love to hear from you. Our team is here to help you
          get the most out of your pharmacy management system.
        </p>
        <div style={{ display: 'flex', gap: '16px', flexWrap: 'wrap', marginBottom: '20px' }}>
          <a href="https://www.instagram.com/shiva_pashamwad_0208/" target="_blank" rel="noopener noreferrer" className="about-link">
            <img src="/images/instagram-logo.svg" alt="Instagram" style={{ width: '20px', height: '20px', marginRight: '8px' }} />
            Instagram
          </a>
          <a href="https://wa.me/9542066782" target="_blank" rel="noopener noreferrer" className="about-link">
            <img src="/images/whatsapp-logo.svg" alt="WhatsApp" style={{ width: '20px', height: '20px', marginRight: '8px' }} />
            WhatsApp
          </a>
        </div>
        <div style={{ display: 'flex', gap: '16px', flexWrap: 'wrap' }}>
          <Link to="/dashboard" className="about-link">
            <span>🏠</span> Back to Dashboard
          </Link>
          <Link to="/tech-stack" className="about-link">
            <span>🛠️</span> View Technology Stack
          </Link>
        </div>
      </div>
    </div>
  );
}

export default AboutPage;