import { useEffect, useRef, useState } from "react";
import { toast } from "react-toastify";

function ExpiryAlertsPage() {
  const [alerts, setAlerts] = useState([]);
  const [losses, setLosses] = useState({ expiredBatches: [], summary: { totalLoss: 0, totalExpiredQuantity: 0, totalExpiredBatches: 0 } });
  const [loading, setLoading] = useState(true);
  const [days, setDays] = useState(30);
  const [searchTerm, setSearchTerm] = useState("");

  const prevCriticalRef = useRef(0);
  const abortRef = useRef(null);

  const fetchData = () => {
    if (abortRef.current) abortRef.current.abort();
    abortRef.current = new AbortController();

    setLoading(true);

    Promise.all([
      fetch(`/api/reports/expiry?days=${days}`, {
        headers: { Authorization: localStorage.getItem("token") },
        signal: abortRef.current.signal
      }),
      fetch(`/api/reports/losses`, {
        headers: { Authorization: localStorage.getItem("token") },
        signal: abortRef.current.signal
      })
    ])
    .then(([expiryRes, lossRes]) => {
      if (!expiryRes.ok || !lossRes.ok) throw new Error("Unauthorized");
      return Promise.all([expiryRes.json(), lossRes.json()]);
    })
    .then(([expiryData, lossData]) => {
      setAlerts(expiryData);
      setLosses(lossData);

      const criticalCount = expiryData.filter(
        item => item.daysLeft <= 7
      ).length;

      if (
        criticalCount > 0 &&
        prevCriticalRef.current === 0
      ) {
        toast.error(
          `🚨 ${criticalCount} batch(es) expiring within 7 days!`,
          { autoClose: 7000 }
        );
      }

      prevCriticalRef.current = criticalCount;
      setLoading(false);
    })
    .catch(err => {
      if (err.name !== "AbortError") {
        console.error(err);
        setLoading(false);
      }
    });
  };

  useEffect(() => {
    fetchData();
    const interval = setInterval(fetchData, 30000);

    return () => {
      clearInterval(interval);
      if (abortRef.current) abortRef.current.abort();
    };
  }, [days]);

  const filteredAlerts = alerts.filter(item =>
    item.medicineName.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const criticalCount = alerts.filter(item => item.daysLeft <= 7).length;
  const warningCount = alerts.filter(item => item.daysLeft <= 30 && item.daysLeft > 7).length;
  const potentialLoss = alerts.reduce((sum, item) => sum + (item.potentialLoss || 0), 0);

  return (
      <div className="expiry-alerts-wrapper">
        <div className="expiry-header">
          <div className="header-content">
            <h1 className="expiry-title">⏰ Expiry Alerts</h1>
            <p className="expiry-subtitle">Monitor medicine expiry dates and manage stock</p>
          </div>
        </div>

        <div className="alert-stats-grid">
          <div className="alert-stat-card critical-bg">
            <div className="alert-stat-icon">🚨</div>
            <div className="alert-stat-info">
              <h3>Critical</h3>
              <div className="alert-stat-value">{criticalCount}</div>
              <div className="alert-stat-label">≤7 days</div>
            </div>
          </div>
          <div className="alert-stat-card warning-bg">
            <div className="alert-stat-icon">⚠️</div>
            <div className="alert-stat-info">
              <h3>Warning</h3>
              <div className="alert-stat-value">{warningCount}</div>
              <div className="alert-stat-label">≤30 days</div>
            </div>
          </div>
          <div className="alert-stat-card total-bg">
            <div className="alert-stat-icon">💰</div>
            <div className="alert-stat-info">
              <h3>Potential Loss</h3>
              <div className="alert-stat-value">${potentialLoss.toFixed(2)}</div>
              <div className="alert-stat-label">if expired</div>
            </div>
          </div>
          <div className="alert-stat-card critical-bg">
            <div className="alert-stat-icon">📉</div>
            <div className="alert-stat-info">
              <h3>Actual Loss</h3>
              <div className="alert-stat-value">${losses.summary.totalLoss.toFixed(2)}</div>
              <div className="alert-stat-label">{losses.summary.totalExpiredBatches} expired</div>
            </div>
          </div>
        </div>

        <div className="expiry-controls">
          <div className="control-group">
            <label className="control-label">
              📅 Show expiring within:
              <select
                value={days}
                onChange={(e) => setDays(Number(e.target.value))}
                className="expiry-select"
              >
                <option value={7}>7 Days</option>
                <option value={15}>15 Days</option>
                <option value={30}>30 Days</option>
                <option value={60}>60 Days</option>
              </select>
            </label>
          </div>
          <div className="control-group">
            <label className="control-label">
              🔍 Search medicines:
              <input
                type="text"
                placeholder="Search medicines..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="expiry-select"
              />
            </label>
          </div>
        </div>

        {loading ? (
          <div className="loading-container">
            <p>Loading expiry alerts...</p>
          </div>
        ) : filteredAlerts.length === 0 ? (
          <div className="empty-state-alerts">
            <div className="empty-icon">✅</div>
            <h3>No expiry alerts</h3>
            <p>{searchTerm ? "No medicines match your search." : `No medicines expiring in the next ${days} days.`}</p>
          </div>
        ) : (
          <div className="expiry-table-section">
            <div className="table-wrapper">
              <table className="expiry-table">
                <thead>
                  <tr>
                    <th>Medicine</th>
                    <th>Batch</th>
                    <th>Expiry Date</th>
                    <th>Days Left</th>
                    <th>Quantity</th>
                    <th>Potential Loss</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredAlerts.map((item, index) => (
                    <tr key={index} className={`expiry-row ${
                      item.daysLeft <= 7 ? 'critical-row' :
                      item.daysLeft <= 30 ? 'warning-row' : 'normal-row'
                    }`}>
                      <td className="medicine-name">{item.medicineName}</td>
                      <td className="batch-no">{item.batchNo}</td>
                      <td className="expiry-date">{new Date(item.expiryDate).toDateString()}</td>
                      <td className="days-left">
                        <span className="days-badge">{item.daysLeft} days</span>
                      </td>
                      <td className="quantity">{item.quantity}</td>
                      <td className="quantity">${(item.potentialLoss || 0).toFixed(2)}</td>
                      <td>
                        <span className={`status-badge ${
                          item.daysLeft <= 7 ? 'critical' :
                          item.daysLeft <= 30 ? 'warning' : 'normal'
                        }`}>
                          {item.daysLeft <= 7 ? 'Critical' :
                           item.daysLeft <= 30 ? 'Warning' : 'Normal'}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
  );
}

export default ExpiryAlertsPage;