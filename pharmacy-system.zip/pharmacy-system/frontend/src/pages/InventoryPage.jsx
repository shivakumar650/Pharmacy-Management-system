import Inventory from "../Inventory";

export default function InventoryPage() {
  return <Inventory />;
}