import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

function InvoicesPage() {
  const [invoices, setInvoices] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    fetchInvoices();
  }, []);

  const fetchInvoices = async () => {
    try {
      const res = await fetch('/api/sales', {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      if (res.ok) {
        const data = await res.json();
        setInvoices(data);
      }
    } catch (error) {
      console.error('Fetch error:', error);
    }
  };

  const printInvoice = (invoice) => {
    const printWindow = window.open('', '', 'width=800,height=600');
    printWindow.document.write(`
      <html>
        <head>
          <title>Invoice ${invoice.invoiceNumber}</title>
          <style>
            body { font-family: Arial, sans-serif; padding: 40px; }
            h1 { color: #2563eb; }
            table { width: 100%; border-collapse: collapse; margin: 20px 0; }
            th, td { padding: 12px; text-align: left; border-bottom: 1px solid #ddd; }
            th { background: #f0f9ff; }
            .total { font-size: 20px; font-weight: bold; text-align: right; margin-top: 20px; }
          </style>
        </head>
        <body>
          <h1>PharmaCare Invoice</h1>
          <p><strong>Invoice #:</strong> ${invoice.invoiceNumber}</p>
          <p><strong>Date:</strong> ${new Date(invoice.soldAt).toLocaleDateString()}</p>
          <p><strong>Customer:</strong> ${invoice.customer?.name || 'Walk-in Customer'}</p>
          ${invoice.customer?.phone ? `<p><strong>Phone:</strong> ${invoice.customer.phone}</p>` : ''}
          
          <table>
            <tr>
              <th>Medicine</th>
              <th>Batch</th>
              <th>Quantity</th>
              <th>Price</th>
              <th>Total</th>
            </tr>
            <tr>
              <td>${invoice.medicine?.name || 'N/A'}</td>
              <td>${invoice.batch?.batchNo || 'N/A'}</td>
              <td>${invoice.quantity}</td>
              <td>$${invoice.sellingPrice.toFixed(2)}</td>
              <td>$${invoice.totalAmount.toFixed(2)}</td>
            </tr>
          </table>
          
          <div class="total">Total Amount: $${invoice.totalAmount.toFixed(2)}</div>
          
          <p style="margin-top: 40px; text-align: center; color: #666;">Thank you for your business!</p>
        </body>
      </html>
    `);
    printWindow.document.close();
    printWindow.print();
  };

  return (
    <div className="page-container">
      <div className="page-header">
        <h1>📄 Invoices</h1>
      </div>

      <div className="table-container">
        <table>
          <thead>
            <tr>
              <th>Invoice #</th>
              <th>Date</th>
              <th>Customer</th>
              <th>Medicine</th>
              <th>Amount</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {invoices.length === 0 ? (
              <tr>
                <td colSpan="6" style={{ textAlign: 'center', padding: '40px' }}>
                  No invoices found
                </td>
              </tr>
            ) : (
              invoices.map(invoice => (
                <tr key={invoice._id}>
                  <td>{invoice.invoiceNumber}</td>
                  <td>{new Date(invoice.soldAt).toLocaleDateString()}</td>
                  <td>{invoice.customer?.name || 'Walk-in'}</td>
                  <td>{invoice.medicine?.name}</td>
                  <td>${invoice.totalAmount.toFixed(2)}</td>
                  <td>
                    <button onClick={() => printInvoice(invoice)}>Print</button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default InvoicesPage;
