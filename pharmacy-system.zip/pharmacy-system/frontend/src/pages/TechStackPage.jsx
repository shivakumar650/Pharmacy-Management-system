import { Link } from "react-router-dom";

function TechStackPage() {
  return (
    <div className="page-container">
      <div className="page-header">
        <h1>🛠️ Technology Stack & Quick Actions</h1>
        <p>Explore our technology foundation and access key features</p>
      </div>

      {/* Technology Stack */}
      <section className="section">
        <h2>🛠️ Technology Stack</h2>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '24px' }}>
          <div style={{ textAlign: 'center', padding: '24px', background: 'linear-gradient(135deg, rgba(37, 99, 235, 0.1), rgba(16, 185, 129, 0.1))', borderRadius: '12px' }}>
            <div style={{ fontSize: '48px', marginBottom: '12px' }}>⚛️</div>
            <h4 style={{ margin: '0 0 8px 0', color: 'var(--text-color)' }}>Frontend</h4>
            <p style={{ margin: '0', color: 'var(--text-muted)', fontSize: '14px' }}>React 19, Vite, CSS3</p>
          </div>
          <div style={{ textAlign: 'center', padding: '24px', background: 'linear-gradient(135deg, rgba(16, 185, 129, 0.1), rgba(245, 158, 11, 0.1))', borderRadius: '12px' }}>
            <div style={{ fontSize: '48px', marginBottom: '12px' }}>🚀</div>
            <h4 style={{ margin: '0 0 8px 0', color: 'var(--text-color)' }}>Backend</h4>
            <p style={{ margin: '0', color: 'var(--text-muted)', fontSize: '14px' }}>Node.js, Express.js</p>
          </div>
          <div style={{ textAlign: 'center', padding: '24px', background: 'linear-gradient(135deg, rgba(245, 158, 11, 0.1), rgba(239, 68, 68, 0.1))', borderRadius: '12px' }}>
            <div style={{ fontSize: '48px', marginBottom: '12px' }}>🗄️</div>
            <h4 style={{ margin: '0 0 8px 0', color: 'var(--text-color)' }}>Database</h4>
            <p style={{ margin: '0', color: 'var(--text-muted)', fontSize: '14px' }}>MongoDB, Mongoose</p>
          </div>
          <div style={{ textAlign: 'center', padding: '24px', background: 'linear-gradient(135deg, rgba(239, 68, 68, 0.1), rgba(37, 99, 235, 0.1))', borderRadius: '12px' }}>
            <div style={{ fontSize: '48px', marginBottom: '12px' }}>🔐</div>
            <h4 style={{ margin: '0 0 8px 0', color: 'var(--text-color)' }}>Security</h4>
            <p style={{ margin: '0', color: 'var(--text-muted)', fontSize: '14px' }}>JWT, bcrypt, CORS</p>
          </div>
        </div>
      </section>

      {/* Quick Actions */}
      <section className="section">
        <h2>⚡ Quick Actions</h2>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))', gap: '20px' }}>
          <Link to="/inventory" style={{ textDecoration: 'none' }}>
            <div style={{ padding: '24px', background: 'linear-gradient(135deg, rgba(37, 99, 235, 0.1), rgba(37, 99, 235, 0.05))', borderRadius: '12px', border: '1px solid rgba(37, 99, 235, 0.2)', transition: 'transform 0.2s', cursor: 'pointer' }} className="quick-action-card">
              <h4 style={{ margin: '0 0 12px 0', color: 'var(--primary-color)' }}>📦 Manage Inventory</h4>
              <p style={{ margin: '0 0 16px 0', color: 'var(--text-light)', fontSize: '14px' }}>Add, update, and monitor your medicine inventory with real-time tracking.</p>
              <button style={{ background: 'var(--primary-color)', color: 'white', border: 'none', padding: '8px 16px', borderRadius: '6px', cursor: 'pointer' }}>Go to Inventory</button>
            </div>
          </Link>
          <Link to="/expiry-alerts" style={{ textDecoration: 'none' }}>
            <div style={{ padding: '24px', background: 'linear-gradient(135deg, rgba(245, 158, 11, 0.1), rgba(245, 158, 11, 0.05))', borderRadius: '12px', border: '1px solid rgba(245, 158, 11, 0.2)', transition: 'transform 0.2s', cursor: 'pointer' }} className="quick-action-card">
              <h4 style={{ margin: '0 0 12px 0', color: 'var(--warning-color)' }}>⏰ Check Expiry Alerts</h4>
              <p style={{ margin: '0 0 16px 0', color: 'var(--text-light)', fontSize: '14px' }}>Monitor medicines nearing expiry and ensure patient safety.</p>
              <button style={{ background: 'var(--warning-color)', color: 'white', border: 'none', padding: '8px 16px', borderRadius: '6px', cursor: 'pointer' }}>View Alerts</button>
            </div>
          </Link>
          <div style={{ padding: '24px', background: 'linear-gradient(135deg, rgba(16, 185, 129, 0.1), rgba(16, 185, 129, 0.05))', borderRadius: '12px', border: '1px solid rgba(16, 185, 129, 0.2)' }}>
            <h4 style={{ margin: '0 0 12px 0', color: 'var(--success-color)' }}>📊 Generate Reports</h4>
            <p style={{ margin: '0 0 16px 0', color: 'var(--text-light)', fontSize: '14px' }}>Export comprehensive reports for analysis and compliance.</p>
            <button
              style={{ background: 'var(--success-color)', color: 'white', border: 'none', padding: '8px 16px', borderRadius: '6px', cursor: 'pointer' }}
              onClick={() => {
                // Export functionality can be implemented here
                alert('Export functionality will be available in the respective pages');
              }}
            >
              Export Data
            </button>
          </div>
        </div>
      </section>

      <div className="tech-navigation">
        <div style={{ display: 'flex', gap: '16px', flexWrap: 'wrap', justifyContent: 'center' }}>
          <Link to="/dashboard" className="tech-link">
            <span>🏠</span> Back to Dashboard
          </Link>
          <Link to="/about" className="tech-link">
            <span>ℹ️</span> About PharmaCare
          </Link>
        </div>
      </div>
    </div>
  );
}

export default TechStackPage;